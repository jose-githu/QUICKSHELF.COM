<?php
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../core/Auth.php';

class AuthController extends Controller {
    private $user;
    public function __construct($conn) { $this->user = new User($conn); }

    public function register($data) {
        $hashed = Auth::hash($data['password']);
        $this->user->create($data['name'], $data['email'], $hashed);
        $this->json(["message" => "User registered"]);
    }
}
?>