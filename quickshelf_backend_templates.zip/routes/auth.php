<?php
require_once "../config/database.php";
require_once "../controllers/AuthController.php";

$db = new Database();
$conn = $db->connect();

$controller = new AuthController($conn);

$input = json_decode(file_get_contents("php://input"), true);
$controller->register($input);
?>