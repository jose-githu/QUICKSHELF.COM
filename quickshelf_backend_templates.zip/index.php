<?php
header("Content-Type: application/json");
echo json_encode(["status" => "QuickShelf Backend Running"]);
?>