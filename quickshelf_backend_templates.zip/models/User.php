<?php
class User extends Model {
    public function create($name, $email, $password) {
        $stmt = $this->conn->prepare("INSERT INTO users(name,email,password) VALUES(?,?,?)");
        $stmt->bind_param("sss", $name, $email, $password);
        return $stmt->execute();
    }
}
?>